# Manjit Tournament — Mobile App (Expo scaffold)

This archive contains a ready-to-build **Expo-managed React Native** project scaffold for **Manjit Tournament**.
It is configured for both Android and iOS builds (via Expo or EAS).

**Package ID:** com.manjit.tournament
**App name:** Manjit Tournament
**Default admin:** rnmanjit2844@gmail.com / Kalpana@2844
**Support WhatsApp:** +9779707138192
**Copyright / Publisher:** © 2025 Manjit Rana Inc.

---

## What's included
- `App.js` — main app skeleton (home, wallet, profile, admin mockups).
- `app.json` — Expo config with package id and metadata.
- `package.json` — project dependencies (Expo SDK minimal).
- `assets/` — placeholder folders for `icon.png` and `splash.png` (replace with your custom logo).
- `README` with build instructions for Android (APK) and iOS (IPA) using Expo / EAS.

## How to build (quick)

### Prerequisites
- Node.js (14+), npm or yarn
- Expo CLI: `npm install -g expo-cli`
- (Optional but recommended) EAS CLI for production builds: `npm install -g eas-cli`
- For iOS builds you need an Apple Developer account to sign IPA builds when using EAS.

### Local test (Expo Go)
1. `npm install`
2. `expo start` — scan QR with Expo Go on your phone to test.

### Create Android APK (development, quick)
1. `expo build:android -t apk` (legacy build) or use EAS for modern builds:
2. `eas build -p android --profile preview` (requires EAS login and configuration)
3. Download generated APK from Expo/EAS build page and install on device.

### Create iOS IPA (requires Apple Developer account)
1. `eas build -p ios` — follow EAS prompts to configure credentials and certificate signing.

---

## Important notes & next steps
- Replace `assets/icon.png` with your custom logo (square, 1024x1024 recommended).
- Replace `assets/splash.png` with a suitable splash image (recommended 1242x2436).
- Replace placeholder text and complete server endpoints for secure payment verification (eSewa), admin auth (JWT), and real-time tournament updates (Socket.IO).
- Use the provided admin credentials only for initial testing. Change credentials & secure admin route before production.
- Keep your Android keystore / iOS certificates safe when publishing.

If you want, I can now:
- produce a debug APK (signed with a debug keystore) and give you the file (I cannot sign official releases without your keystore),
- or prepare an EAS build configuration file for one-command production builds.

Reply which one you want next and I will produce it immediately.
