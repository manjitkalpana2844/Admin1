import React from 'react';
import { View, Text, Button, Image, ScrollView } from 'react-native';
import { StatusBar } from 'expo-status-bar';

export default function App() {
  return (
    <ScrollView contentContainerStyle={{ flexGrow: 1, backgroundColor: '#F3F4F6' }}>
      <StatusBar style="dark" />
      <View style={{ padding: 20, backgroundColor: '#16A34A' }}>
        <Text style={{ color: 'white', fontSize: 20, fontWeight: '700' }}>Manjit Tournament</Text>
        <Text style={{ color: 'white', marginTop: 4 }}>Support: WhatsApp +9779707138192</Text>
      </View>

      <View style={{ padding: 20 }}>
        <Text style={{ fontSize: 18, fontWeight: '700' }}>Home — Ongoing Tournaments</Text>
        <View style={{ marginTop: 12, padding: 12, backgroundColor: 'white', borderRadius: 8 }}>
          <Text style={{ fontWeight: '700' }}>Liga 1 — Night Royale</Text>
          <Text style={{ color: '#374151', marginTop: 6 }}>Prize: NPR 1000 • Entry: NPR 30</Text>
          <Button title="Join" onPress={() => alert('Join flow — replace with real API')} />
        </View>
      </View>

      <View style={{ padding: 20 }}>
        <Text style={{ fontSize: 18, fontWeight: '700' }}>Profile</Text>
        <View style={{ marginTop: 12, padding: 12, backgroundColor: 'white', borderRadius: 8 }}>
          <Text>Username: DragonSlayer</Text>
          <Text>Phone: 9707138192</Text>
          <Button title="Edit Profile" onPress={() => alert('Edit profile — implement API')} />
        </View>
      </View>

      <View style={{ padding: 20 }}>
        <Text style={{ fontSize: 18, fontWeight: '700' }}>Wallet</Text>
        <View style={{ marginTop: 12, padding: 12, backgroundColor: 'white', borderRadius: 8 }}>
          <Text>Balance: NPR 250</Text>
          <Button title="Topup via eSewa" onPress={() => alert('Topup — open eSewa link')} />
        </View>
      </View>

      <View style={{ padding: 20, alignItems: 'center', marginTop: 20 }}>
        <Image source={require('./assets/icon.png')} style={{ width: 120, height: 120, resizeMode: 'contain' }} />
        <Text style={{ marginTop: 8, color: '#6B7280' }}>© 2025 Manjit Rana Inc.</Text>
      </View>
    </ScrollView>
  );
}
